###2nd deliverable - MICRO

To build the executables of this deliverable simply type 'make' in the same directory
as the source files and all the .exe's will be automatically generated.

The whole process can be reversed just by typing 'make clean'
