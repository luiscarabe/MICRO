###3rd Deliverable - Juan Riera Gomez and Luis Cárabe Fernández-Pedraza
#Group 2351, team 02
To generate the executables just type 'make' and they will be automatically generated.
All the executables can be removed just by typing 'make clean'
